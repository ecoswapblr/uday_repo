// Toast helper
window.AppToast = (function () {
    function show(message, type) {
        var toastEl = document.getElementById("global-toast");
        var toastBody = document.getElementById("global-toast-body");
        if (!toastEl || !toastBody) return;
        toastBody.textContent = message || "";
        toastEl.classList.remove("text-bg-primary", "text-bg-success", "text-bg-danger", "text-bg-warning");
        if (type === "success") toastEl.classList.add("text-bg-success");
        else if (type === "error") toastEl.classList.add("text-bg-danger");
        else if (type === "warning") toastEl.classList.add("text-bg-warning");
        else toastEl.classList.add("text-bg-primary");
        var bsToast = new bootstrap.Toast(toastEl, { delay: 4500 });
        bsToast.show();
    }
    return { show: show };
})();

(function () {
    var loaderBackdrop = null;

    function ensureLoader() {
        if (loaderBackdrop) return loaderBackdrop;
        loaderBackdrop = document.createElement("div");
        loaderBackdrop.className = "import-loader-backdrop";
        loaderBackdrop.innerHTML = '<div class="import-loader"></div>';
        document.body.appendChild(loaderBackdrop);
        return loaderBackdrop;
    }

    document.addEventListener("DOMContentLoaded", function () {
        var payload = document.getElementById("toast-payload");
        if (payload && payload.dataset.message) {
            AppToast.show(payload.dataset.message, payload.dataset.type || "success");
        }

        var forms = document.querySelectorAll("form[data-form-with-loader='true']");
        forms.forEach(function (form) {
            form.addEventListener("submit", function () {
                ensureLoader();
                loaderBackdrop.classList.add("show");
                var btn = form.querySelector("button[type='submit']");
                if (btn) {
                    btn.disabled = true;
                    btn.setAttribute("data-original-html", btn.innerHTML);
                    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Processing...';
                }
            });
        });
    });

    window.addEventListener("pageshow", function (e) {
        if (e.persisted && loaderBackdrop) {
            loaderBackdrop.classList.remove("show");
            document.querySelectorAll("form[data-form-with-loader='true'] button[type='submit']").forEach(function (btn) {
                btn.disabled = false;
                if (btn.getAttribute("data-original-html")) btn.innerHTML = btn.getAttribute("data-original-html");
            });
        }
    });
})();
