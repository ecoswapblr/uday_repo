# Zoho Sheet setup for SheetSyncApp

SheetSyncApp talks to **Zoho Sheet** using OAuth2: a **refresh token** plus **client ID/secret**. Your Zoho account may be on **`.in`**, **`.com`**, or **`.eu`** data centers; API and token URLs must match that region.

---

## 1. Register an app in Zoho API Console

1. Open [Zoho API Console](https://api-console.zoho.com/) (or the regional console if Zoho redirects you, e.g. India).
2. Click **Add Client** / **Get Started** → create a **Server-based Applications** client.
3. Set:
   - **Client Name** — e.g. `SheetSyncApp`
   - **Homepage URL** — your site or `https://localhost` for dev
   - **Authorized Redirect URI** — must match exactly what you use in the OAuth step (e.g. `https://localhost` or a small redirect page you control)

4. Save and note **Client ID** and **Client Secret**.

---

## 2. OAuth scopes

SheetSyncApp needs read/write access to sheet data. Use scopes such as:

- `ZohoSheet.dataAPI.READ`
- `ZohoSheet.dataAPI.UPDATE`

In the authorization URL, scopes are often comma-separated or space-separated depending on the docs/Zoho UI you use. Example (adjust domain):

```text
ZohoSheet.dataAPI.READ,ZohoSheet.dataAPI.UPDATE
```

---

## 3. Get a refresh token (one-time; keep it secret)

You need a browser step once (or use Zoho’s documented OAuth tools):

1. Build an **authorize** URL (replace placeholders):

   - **India (.in)** accounts example:  
     `https://accounts.zoho.in/oauth/v2/auth`
   - **US (.com)** might use:  
     `https://accounts.zoho.com/oauth/v2/auth`

   Query parameters typically include:

   - `scope` — the scopes above
   - `client_id` — from API Console
   - `response_type` — `code`
   - `access_type` — **`offline`** (required to get a refresh token)
   - `prompt` — **`consent`** (recommended so refresh token is returned reliably)
   - `redirect_uri` — must match the client’s registered redirect URI

2. Open the URL in a browser, sign in, click **Accept**.

3. Zoho redirects to your `redirect_uri` with a **`code`** query parameter.

4. Exchange the code for tokens with a **POST** to the token endpoint (same region as accounts), for example for India:

   - `https://accounts.zoho.in/oauth/v2/token`

   Body (form-urlencoded) usually includes:

   - `grant_type=authorization_code`
   - `client_id`, `client_secret`
   - `redirect_uri` (same as above)
   - `code` (from the redirect)

5. Response JSON includes **`refresh_token`** and **`access_token`**. Store **`refresh_token`** securely; SheetSyncApp uses it to obtain short-lived access tokens.

**Security:** Never commit `client_secret` or `refresh_token` to git. Use User Secrets, environment variables, or a secret store in production.

---

## 4. Configure SheetSyncApp (`appsettings`)

Example structure (values are placeholders):

```json
"Zoho": {
  "ClientId": "<your-client-id>",
  "ClientSecret": "<your-client-secret>",
  "RefreshToken": "<your-refresh-token>",
  "TokenEndpoint": "https://accounts.zoho.in/oauth/v2/token",
  "ApiBaseUrl": "https://www.zohoapis.in",
  "Scopes": "ZohoSheet.dataAPI.READ ZohoSheet.dataAPI.UPDATE"
}
```

- **`TokenEndpoint`** must match your **accounts** region (`.in` / `.com` / `.eu`).
- The app calls **Zoho Sheet** Data API hosts such as `https://sheet.zoho.in/...` for workbooks tied to that region; keep your sheet URLs and account region consistent.

---

## 5. Source and destination URLs

- **Destination:** Zoho Sheet “open” links typically look like paths containing `/sheet/open/{resource_id}` — the app parses `resource_id` from that URL.
- **Source:** Use the Zoho Sheet URL for the workbook you import from (same format expectations as your existing config).

---

## 6. Rate limits (operational note)

Zoho documents per-minute limits per workbook; exceeding them can block API use on that document for a short cooldown period. The app includes pacing and retry logic; very large batch writes may still need time or multiple runs.

---

## 7. Verify

1. Fill **Zoho** keys in configuration (dev: User Secrets recommended).
2. In the app, set a financial year to provider **Zoho** with valid source/destination URLs.
3. Run a sync and check logs for token or permission errors.

---

## Reference

- [Zoho Sheet Data API help (API v2)](https://www.zoho.com/sheet/help/api/v2/)
- [Zoho OAuth documentation](https://www.zoho.com/accounts/protocol/oauth.html) (verify current parameter names for your region)
