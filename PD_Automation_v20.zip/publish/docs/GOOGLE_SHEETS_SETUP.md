# Google Sheets & Drive setup for SheetSyncApp

This app uses a **Google Cloud service account** to read/write spreadsheets. You enable APIs in Google Cloud, create a key (JSON), place it in the project, and **share each destination spreadsheet** with the service account email.

---

## 1. Create or pick a Google Cloud project

1. Open [Google Cloud Console](https://console.cloud.google.com/).
2. Select an existing project or **Create project**.

---

## 2. Enable APIs

1. In the console go to **APIs & Services → Library** (or search “API Library”).
2. Enable **Google Sheets API**.
3. Enable **Google Drive API** as well.  
   - Some flows (exports, file access patterns) expect Drive to be available; enabling both avoids intermittent “API not enabled” errors.

---

## 3. Create a service account

1. Go to **APIs & Services → Credentials**.
2. Click **Create credentials → Service account**.
3. Give it a name (e.g. `sheetsync-app`), create it.
4. Optional: skip granting project roles unless you use other GCP features; Sheets access is via **spreadsheet sharing**, not IAM on Drive for normal usage.

---

## 4. Create and download the JSON key

1. Open the service account you just created.
2. Go to the **Keys** tab → **Add key → Create new key**.
3. Choose **JSON** and download the file.
4. **Security:** treat this file like a password. Do not commit it to public repos. Prefer [User Secrets](https://learn.microsoft.com/en-us/aspnet/core/security/app-secrets) or environment variables in production.

---

## 5. Put the JSON where SheetSyncApp expects it

The code looks up credentials in this order:

1. Configuration key **`Google:ServiceAccountKeyPath`** (full or relative path to the JSON file), **or**
2. Default: a file named **`sheetssync-489503-1630e2273c66.json`** in the application **content root** (typically the project folder next to `appsettings.json` when you run from Visual Studio / `dotnet run`).

### Option A — Replace the default file (simplest for local dev)

1. Save your downloaded key as:
   - `sheetssync-489503-1630e2273c66.json`  
   in the SheetSyncApp project root (same folder as `SheetSyncApp.csproj` / `appsettings.json`).
2. Add this filename to `.gitignore` if it is not already ignored, so the real key is never committed.

### Option B — Any path via configuration

In `appsettings.json` or `appsettings.Development.json` (or User Secrets):

```json
"Google": {
  "ServiceAccountKeyPath": "C:\\secure\\folder\\my-service-account.json"
}
```

Use a path that exists on the machine where the app runs.

---

## 6. Grant access to spreadsheets

1. Open the downloaded JSON and find **`client_email`** (ends with `@...iam.gserviceaccount.com`).
2. In **Google Sheets**, open each **source** and **destination** spreadsheet → **Share**.
3. Add that email with **Editor** access (Viewer is not enough for writes).

Without this step you will see permission / not-found style errors even though the JSON is valid.

---

## 7. Verify in the app

1. Set **Source URL** and **Destination URL** in the app config UI for a financial year using provider **Google**.
2. Run a sync or use any “validate destination” action if present.
3. If something fails, check the log message: it often mentions sharing with `client_email`.

---

## Common issues

| Symptom | What to check |
|--------|----------------|
| API not enabled | Sheets API + Drive API enabled for the **same** GCP project as the service account |
| Permission denied | Destination (and source) shared with `client_email` as **Editor** |
| File not found | Path in `Google:ServiceAccountKeyPath` or default JSON name/location on the server |

---

## Reference

- [Google Sheets API](https://developers.google.com/sheets/api)
- [Service accounts](https://cloud.google.com/iam/docs/service-accounts)
